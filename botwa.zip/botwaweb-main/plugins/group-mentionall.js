let handler = async (m, { conn, text, usedPrefix, command }) => {
	const guild = require("./guild-1.json");
	const phoneNumbers = guild.members.map((member) => member.phone);

	const filteredParticipants = participants.filter((participant) => phoneNumbers.includes(participant));

	const mentions = await Promise.all(filteredParticipants.map(jid => conn.getChatById(jid)));

	conn.sendMessage(m.id.remote, teks, { mentions: filteredParticipants });
}

handler.help = ['hidetag'].map(v => v + ' <text>')
handler.tags = ['owner']
handler.command = /^(pengumuman|announce|hiddentag|hidetag)$/i

handler.admin = true
handler.group = true

export default handler;
