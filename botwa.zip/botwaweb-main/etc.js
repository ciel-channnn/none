/*
author: https://github.com/Ftwrr
*/

const prefix = false
const APIs = { // API Prefix
    // name: 'https://website'
}
const APIKeys = { // APIKey Here
    // 'https://website': 'apikey'
}
const opts = {
    self: false,
    //simsimi: false
}
const owner = '6283894013398'

const author = 'Ciel-Chan≧ω≦'

export default { APIs, APIKeys, opts, prefix, owner, author }
